﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BusinessLogicLayer;
using System.Data.SqlClient;
namespace HotelReservationSystem
{
    public partial class Admin_AddHotel : Form
    {
        BusinessAccessClass bac = new BusinessAccessClass();
        
        public Admin_AddHotel()
        {
            InitializeComponent();
            cboxCountry.Items.Add("Select Country");
            DataSet ds = bac.GetData("spGetCountry", null);
            cboxCountry.DisplayMember = "Country_Name";
            cboxCountry.ValueMember = "Country_Id";
            cboxCountry.DataSource = ds.Tables[0];

            cboxCity.Enabled = false;
        }

  

        private void Admin_AddHotel_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;
        }

        private void cboxCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            cboxCity.Enabled = true;
            string sp = "spGetCityByCountryId";
            SqlParameter parameter = new SqlParameter("@Country_Id", cboxCountry.SelectedValue);
            DataSet ds = bac.GetData(sp, parameter);
            cboxCity.DataSource = ds.Tables[0];
            cboxCity.DisplayMember = "City_Name";
            cboxCity.ValueMember = "City_Id";
        }

        private void btnAddHotel_Click(object sender, EventArgs e)
        {
            int i=bac.addHotel(txtHotelName.Text,cboxCountry.SelectedValue.ToString(),cboxCity.SelectedValue.ToString(),txtHotelDesc.Text,Convert.ToInt32(txtNumAcRooms.Text),Convert.ToInt32(txtNumNonAcRooms.Text),Convert.ToInt32(txtRateAdultAc.Text),Convert.ToInt32(txtRateAdultNonAc.Text),Convert.ToInt32(txtRateChildAc.Text),Convert.ToInt32(txtRateChildNonAc.Text));
            if (i == 1)
            {
                MessageBox.Show("Hotel Added Successfully");
                foreach (Control c in this.Controls)
                {
                    if (c is TextBox)
                        c.Text = "";
                    else if (c is ComboBox)
                        if (c.Name == "cboxCity")
                            c.Enabled = false;

                }
            }
            else
                MessageBox.Show("Hotel Not Added Successfully");
            
        }

      
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BusinessLogicLayer;
using System.Data.SqlClient;

namespace HotelReservationSystem
{
    public partial class Admin_DeleteHotel : Form
    {
        public Admin_DeleteHotel()
        {
            InitializeComponent();
            txtHotelId.Select();
        }

        private void Admin_DeleteHotel_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;
        }

        private void btnSearchHotel_Click(object sender, EventArgs e)
        {
            BusinessAccessClass bac = new BusinessAccessClass();
            DataSet ds= bac.getHotelDetailByHotelId(txtHotelId.Text);
            if (ds != null)
            {
                    txtHotelName.Text = ds.Tables[0].Rows[0]["Hotel_Name"].ToString();
                    txtCountry.Text = ds.Tables[0].Rows[0]["Country_Id"].ToString();
                    txtCity.Text = ds.Tables[0].Rows[0]["City_Id"].ToString();
                    txtHotelDesc.Text = ds.Tables[0].Rows[0]["Hotel_Description"].ToString();
                    txtNumAcRooms.Text = ds.Tables[0].Rows[0]["No_Of_Ac_Room"].ToString();
                    txtNumNonAcRooms.Text = ds.Tables[0].Rows[0]["No_Of_Non_Ac_Room"].ToString();
                    txtRateChildAc.Text = ds.Tables[0].Rows[0]["Rate_Child_Ac"].ToString();
                    txtRateChildNonAc.Text = ds.Tables[0].Rows[0]["Rate_Child_Non_Ac"].ToString();
                    txtRateAdultAc.Text = ds.Tables[0].Rows[0]["Rate_Adult_Ac"].ToString();
                    txtRateAdultNonAc.Text = ds.Tables[0].Rows[0]["Rate_Adult_Non_Ac"].ToString();
            }   
            else if (ds == null)
            {
                MessageBox.Show("Please Enter Correct Hotel_Id");   
            }
        }

        private void btnDeleteHotel_Click(object sender, EventArgs e)
        {
            if (txtHotelName != null && txtHotelId.Text!=null)
            {
                if (MessageBox.Show("Are You Sure You Want To Delete Hotel : "+txtHotelId.Text+"?", "Confirm Deletion", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    BusinessAccessClass bac = new BusinessAccessClass();
                    int i = bac.deleteHotel(txtHotelId.Text);
                    if (i > 0)
                    {
                        MessageBox.Show("Hotel Details Of Hotel : " + txtHotelId.Text + "Deleted Successfully");
                    }
                    else 
                    {
                        MessageBox.Show("Deletion Unsucessful. Try Later...");
                    }
                }
            }
            else
            {
                MessageBox.Show("First Select Hotel For Deletion");
            }
        }

    }
}
